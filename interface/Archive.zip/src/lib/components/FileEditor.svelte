<script>
  import { onMount } from 'svelte';
  import { EditorView, basicSetup } from '@codemirror/basic-setup';
  import { EditorState } from '@codemirror/state';
  import { javascript } from '@codemirror/lang-javascript';

  let editor;

  // This will hold the file content
  let content = `// Start editing...\nconsole.log('Hello, ESP32!');`;

  onMount(() => {
    const state = EditorState.create({
      doc: content,
      extensions: [basicSetup, javascript()]
    });

    editor = new EditorView({
      state,
      parent: document.querySelector('#editor')
    });
  });
</script>

<h2>File Editor</h2>
<div id="editor" style="height: 400px; border: 1px solid #ccc;"></div>